package stateless.kaffeepause;

public class Kaffee {
	private int anzahlTassen;

	public Kaffee(int anzahlTassen) {
		this.anzahlTassen = anzahlTassen;
	}

	public int getAnzahlTassen() {
		return anzahlTassen;
	}

}
