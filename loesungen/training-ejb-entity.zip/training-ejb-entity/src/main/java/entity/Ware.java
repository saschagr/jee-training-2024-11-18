package entity;

import java.io.Serializable;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Version;

@Entity
public class Ware implements Serializable {
	
	@Id
	@GeneratedValue
	private Long id;

	private String artikelnummer;
	private int preis;
	private int anzahl;
	
	@Version
	private int version;
	
	public Ware() {}
	
	public Ware(String artikelnummer, int preis, int anzahl) {
		super();
		this.artikelnummer = artikelnummer;
		this.preis = preis;
		this.anzahl = anzahl;
	}
	
	

	@Override
	public String toString() {
		return "Ware [id=" + id + ", artikelnummer=" + artikelnummer + ", preis=" + preis + ", anzahl=" + anzahl
				+ ", version=" + version + "]";
	}

	public String getArtikelnummer() {
		return artikelnummer;
	}

	public void setArtikelnummer(String artikelnummer) {
		this.artikelnummer = artikelnummer;
	}

	public int getPreis() {
		return preis;
	}

	public void setPreis(int preis) {
		this.preis = preis;
	}

	public int getAnzahl() {
		return anzahl;
	}

	public void setAnzahl(int anzahl) {
		this.anzahl = anzahl;
	}

	public Long getId() {
		return id;
	}

	public int getVersion() {
		return version;
	}
	
	
}
