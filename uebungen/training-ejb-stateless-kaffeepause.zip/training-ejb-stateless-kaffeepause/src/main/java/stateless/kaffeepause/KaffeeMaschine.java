package stateless.kaffeepause;

import java.util.concurrent.Future;

public interface KaffeeMaschine {


	public Future<Kaffee> kocheKaffee();

}