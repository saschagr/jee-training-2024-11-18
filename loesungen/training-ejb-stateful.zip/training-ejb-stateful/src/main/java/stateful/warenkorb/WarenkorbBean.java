package stateful.warenkorb;

import java.util.HashMap;
import java.util.Map;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.annotation.Resource;
import jakarta.ejb.SessionContext;
import jakarta.ejb.Stateful;
import jakarta.interceptor.Interceptors;
import jakarta.transaction.Transactional;
import jakarta.transaction.Transactional.TxType;

@Stateful
@Interceptors(LifeCycleMonitor.class)
public class WarenkorbBean implements Warenkorb {
	
	private Map<String, Integer> artikel = new HashMap();
	
	@Resource
	private SessionContext sessionContext;

	public void legeInWarenkorb(int anzahl, String artikelnummer, int einzelpreis) {
		artikel.put(artikelnummer, anzahl * einzelpreis);

	}

	public void entferneAusWarenkorb(String artikelnummer) {
		artikel.remove(artikelnummer);

	}

	//@jakarta.ejb.Remove
	public int geheZurKasse() {
		this.sessionContext.getBusinessObject(Warenkorb.class).removeMe();
		
		// so nicht
		// this.removeMe();
		
		return artikel.values().stream().mapToInt(preis -> preis).sum();
	}
	
	@jakarta.ejb.Remove
	public void removeMe() {
		// do nothing
	}
	
	@PostConstruct
	private void postConstruct() {
		System.out.println("postConstruct " + this.getClass().getName());
	}

	@PreDestroy
	private void preDestroy() {
		System.out.println("preDestroy " + this.getClass().getName());
	}
}
