package stateless.zinsdienst;

import jakarta.ejb.Stateless;

@Stateless
public class ZinssatzBean implements Zinssatz {

	@Override
	public double ermittleZinssatz(int anlagebetrag, int jahre) {
		return 0.01 * jahre;
	}

}
