package stateless.warenkorb.entity;

import java.time.LocalDateTime;

import changedata.ChangeData;
import changedata.ChangeableData;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.security.enterprise.SecurityContext;

@Entity
public class Log implements ChangeableData {
	
	@Id
	@GeneratedValue
	private Long id;

	private String nachricht;
	
	@Temporal(TemporalType.TIMESTAMP)
	private LocalDateTime zeitstempel;
	
	@Embedded
	private ChangeData changeData = new ChangeData();


	public Log() {
		super();
	}

	public Log(String nachricht, LocalDateTime zeitstempel) {
		super();
		this.nachricht = nachricht;
		this.zeitstempel = zeitstempel;
	}

	@Override
	public ChangeData getChangeData() {
		return changeData;
	}
	
}
