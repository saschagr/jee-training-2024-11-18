package changedata;

public interface ChangeableData {
	
	ChangeData getChangeData();

}
