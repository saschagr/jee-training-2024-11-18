/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/ 
package stateless.warenkorb;

import java.util.List;

import javax.naming.InitialContext;

public class Client {

	public static void main(String[] args) throws Exception{
	      InitialContext ctx = new InitialContext();

	      WarenkorbRemote korb = (WarenkorbRemote) 
					ctx.lookup("training-ejb-stateless-jpa-warenkorb/WarenkorbStatelessBean!stateless.warenkorb.WarenkorbRemote");
	      
	      Long warenKorbId = korb.erzeugeWarenkorb();
	      
		  korb.legeInWarenkorb(warenKorbId, 3, "0-24342-X", 2);
	      korb.legeInWarenkorb(warenKorbId, 2, "4711-Y", 1);
	      korb.legeInWarenkorb(warenKorbId, 5, "0-815-X", 1);
	      
	      out(korb.zeigeWarenkorb(warenKorbId));
	      
	      korb.legeInWarenkorb(warenKorbId, 1, "0-815-X", 2);
	      
	      out(korb.zeigeWarenkorb(warenKorbId));

	      korb.entferneAusWarenkorb(warenKorbId, "0-24342-X");
	      
	      out(korb.zeigeWarenkorb(warenKorbId));
	      
	      System.out.println("Kosten des Warenkorbs: "
	    		  + korb.geheZurKasse(warenKorbId));

	      out(korb.zeigeWarenkorb(warenKorbId));

	}

	private static void out(List<Ware> waren) {
		System.out.println();
		System.out.println("--- Warenkorbinhalt ---");
		
		waren.forEach(ware -> {
			System.out.printf(
				"%s * %s (%d) - Gesamtpreis: %d",
				ware.getAnzahl(),
				ware.getArtikelnummer(),
				ware.getEinzelpreis(),
				ware.getGesamtpreis()
				);
			System.out.println();
		});
		System.out.println("-----------------------");
		System.out.println();
		
	}

}
