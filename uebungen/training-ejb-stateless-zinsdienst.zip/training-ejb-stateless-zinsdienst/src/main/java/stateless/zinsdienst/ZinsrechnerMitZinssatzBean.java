package stateless.zinsdienst;

import jakarta.ejb.Stateless;

@Stateless
public class ZinsrechnerMitZinssatzBean implements ZinsrechnerMitZinssatz {
	
	@jakarta.ejb.EJB
	//@jakarta.inject.Inject
	private Zinssatz zinssatz;

	@Override
	public int berechneSparSumme(int anlagebetrag, int jahre) {
		double zins = zinssatz.ermittleZinssatz(anlagebetrag, jahre);
		return (int) (anlagebetrag * Math.pow(1+zins, (double) jahre));
	}

}
