package stateless.warenkorb.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import changedata.ChangeData;
import changedata.ChangeableData;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;

@Entity
@NamedQueries({
	@NamedQuery(name=Warenkorb.FIND_WARENKORBS_BY_ARTIKELNUMMER, query="select w from Warenkorb w join w.warenkorbEintrags e where e.artikelnummer = :artikelnummer")
})

public class Warenkorb implements Serializable, ChangeableData {

	private static final long serialVersionUID = 3249250266598504043L;

	public static final String FIND_WARENKORBS_BY_ARTIKELNUMMER = "Warenkorb.FIND_WARENKORBS_BY_ARTIKELNUMMER";

	public static final String PARAM_ARTIKELNUMMER = "artikelnummer";
	
	@Id
	@GeneratedValue
	private Long id;
	
	@ElementCollection
	private List<WarenkorbEintrag> warenkorbEintrags = new ArrayList<>();
	
	@Embedded
	private ChangeData changeData = new ChangeData();
	
	
	public Long getId() {
		return id;
	}

	public List<WarenkorbEintrag> getWarenkorbEintrags() {
		return warenkorbEintrags;
	}

	public void addWarenkorbEintrag(WarenkorbEintrag warenkorbEintrag) {
		this.warenkorbEintrags.add( warenkorbEintrag);
	}

	public void removeWarenkorbEintrag(WarenkorbEintrag warenkorbEintrag) {
		this.warenkorbEintrags.remove( warenkorbEintrag);
	}

	@Override
	public ChangeData getChangeData() {
		return changeData;
	}

}
