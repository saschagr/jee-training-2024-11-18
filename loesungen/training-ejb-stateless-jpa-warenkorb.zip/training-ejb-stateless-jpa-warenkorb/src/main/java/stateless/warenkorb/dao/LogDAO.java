package stateless.warenkorb.dao;

import jakarta.ejb.Stateless;
import jakarta.ejb.TransactionAttribute;
import jakarta.ejb.TransactionAttributeType;
import jakarta.transaction.Transactional;
import jakarta.transaction.Transactional.TxType;
import stateless.warenkorb.entity.Log;

@Stateless
//@TransactionAttribute(TransactionAttributeType.MANDATORY)
public class LogDAO extends AbstractDao<Log>{

	public LogDAO() {
		super(Log.class);
	}

	@Override
	@Transactional(value = TxType.REQUIRES_NEW)
	//@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
	public Log persist(Log entity) {
		return super.persist(entity);
	}
	
	

}
