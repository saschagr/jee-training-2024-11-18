/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/
package jms;

import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.Destination;
import jakarta.jms.Message;
import jakarta.jms.MessageConsumer;
import jakarta.jms.Session;
import jakarta.jms.TextMessage;
import javax.naming.InitialContext;

public class EmpfaengerSynchron {
	public static void main(String[] args) throws Exception {
		InitialContext initialContext = new InitialContext();
		ConnectionFactory factory = (ConnectionFactory) initialContext.lookup("jms/RemoteConnectionFactory");
		Destination postfach = (Destination) initialContext.lookup("jms/queue/Praxisbuch");

		try (Connection connection = factory.createConnection("app", "jboss");
				Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);) {

			connection.start();


			try (MessageConsumer empfaenger = session.createConsumer(postfach, "Bestellungstyp = 'Internet'");) {
				Message nachricht = empfaenger.receive();

				System.out.println("Nachricht empfangen!");
				System.out.println(((TextMessage) nachricht).getText());
			}

			connection.stop();
		}
	}
}