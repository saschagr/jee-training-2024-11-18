# Beispiel JMS

## Vorbereitung

Datei `standalone-full-training.xml` kopieren in
`$WILDFLY_HOME/standalone/configuration/`

Benutzer (Application User) `app` mit Password `jboss` und Role/Gruppe `guest` anlegen

	$WILDFLY_HOME/bin/add-user.bat


## Wildfly starten

	$WILDFLY_HOME/bin/standalone.bat --server-config=standalone-full-training.xml
