/**********************************************************
 * Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
 * Das EJB-Praxisbuch fuer Ein- und Umsteiger
 * Von Werner Eberling und Jan Lessner
 * Hanser Fachbuchverlag Muenchen, 2011
 * http://www.hanser.de/buch.asp?isbn=3-446-42259-5
 * Feedback an ejb3buch@werner-eberling.de
 **********************************************************/
package stateless.warenkorb.bean;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.annotation.Resource;
import jakarta.ejb.EJB;
import jakarta.ejb.SessionContext;
import jakarta.ejb.Stateless;
import jakarta.ejb.TransactionAttribute;
import jakarta.ejb.TransactionAttributeType;

import stateless.warenkorb.Ware;
import stateless.warenkorb.WarenkorbRemote;
import stateless.warenkorb.dao.LogDAO;
import stateless.warenkorb.dao.WarenkorbDao;
import stateless.warenkorb.entity.Log;
import stateless.warenkorb.entity.Warenkorb;
import stateless.warenkorb.entity.WarenkorbEintrag;

@Stateless()
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class WarenkorbStatelessBean implements WarenkorbRemote {
	
	@Resource
	private SessionContext sessionContext;

	@EJB
	private WarenkorbDao warenkorbDao;
	
	@EJB
	private LogDAO logDAO;
	
	@Override
	public Long erzeugeWarenkorb() {
		return this.warenkorbDao.persist(new Warenkorb()).getId();
	}

	@Override
	public void entferneAusWarenkorb(Long warenkorbId, String artikelnummer) {
		if (artikelnummer != null) {
			Warenkorb warenkorb = this.getWarenkorb(warenkorbId);
			Iterator<WarenkorbEintrag> it = warenkorb.getWarenkorbEintrags()
					.iterator();
			while (it.hasNext()) {
				WarenkorbEintrag next = it.next();
				if (next.getArtikelnummer().equals(artikelnummer)) {
					it.remove();
				}
			}
		}
	}

	@Override
	public Long legeInWarenkorb(Long warenkorbId, int anzahl,
			String artikelnummer, int einzelpreis) {
		
		log("legeInWarenkorb( " + warenkorbId + "-" + artikelnummer + " )", LocalDateTime.now());

		Warenkorb warenkorb = this.getWarenkorb(warenkorbId);

		boolean exists = false;
		
		for (WarenkorbEintrag warenkorbEintrag : warenkorb.getWarenkorbEintrags()) {
			if (warenkorbEintrag.getArtikelnummer().equals(artikelnummer)) {
				exists = true;
				warenkorbEintrag.setAnzahl(warenkorbEintrag.getAnzahl() + anzahl);
				warenkorbEintrag.setEinzelpreis(einzelpreis);
			}
		}
		
		if (!exists) {
			warenkorb.addWarenkorbEintrag(new WarenkorbEintrag(anzahl, einzelpreis, artikelnummer));
		}

		return warenkorb.getId();
	}

	@Override
	public int geheZurKasse(Long warenkorbId) {
		log("geheZurKasse( " + warenkorbId + " )", LocalDateTime.now());
		Warenkorb warenkorb = this.getWarenkorb(warenkorbId);

		
		int gesamtpreis = 0;
		for (WarenkorbEintrag warenkorbEintrag : warenkorb.getWarenkorbEintrags()) {
			gesamtpreis += warenkorbEintrag.getAnzahl() * warenkorbEintrag.getEinzelpreis();
		}
		
		
		this.warenkorbDao.remove(warenkorb);
		//sessionContext.setRollbackOnly();
		//throw new RuntimeException();
		return gesamtpreis;
	}

	@Override
	public List<Ware> zeigeWarenkorb(Long warenkorbId) {
		log("zeigeWarenkorb( " + warenkorbId + " )", LocalDateTime.now());
		
		Warenkorb warenkorb = this.getWarenkorb(warenkorbId);

		List<Ware> wares = new ArrayList<>();
		
		for (WarenkorbEintrag warenkorbEintrag : warenkorb.getWarenkorbEintrags()) {
			wares.add(new Ware(warenkorbEintrag.getAnzahl(), warenkorbEintrag.getEinzelpreis(), warenkorbEintrag.getArtikelnummer()));
		}

		return wares;
	}

	private void log(String nachricht, LocalDateTime zeitstempel) {
		logDAO.persist(new Log(nachricht, zeitstempel));
	}


	private Warenkorb getWarenkorb(Long warenkorbId) {
		Warenkorb warenkorb = null;
		if (warenkorbId != null) {
			warenkorb = warenkorbDao.findById(warenkorbId);
		}

		if (warenkorb == null) {
			throw new NullPointerException("Kein Warenkorb vorhanden für die warenkorbId " + warenkorbId);
		} else {
			return warenkorb;
		}
	}

	@PostConstruct
	public void erzeugt() {
		System.out.println("Ich wurde erzeugt.");
	}

	@PreDestroy
	public void beanEntfernt() {
		System.out.println("Ich werde entfernt.");
	}

}
