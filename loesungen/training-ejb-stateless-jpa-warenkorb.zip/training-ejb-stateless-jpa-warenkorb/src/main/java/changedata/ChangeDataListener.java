package changedata;

import java.util.Date;
import java.util.Optional;

import jakarta.inject.Inject;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.security.enterprise.SecurityContext;

public class ChangeDataListener {
	
	@Inject
	private SecurityContext securityContext;

	@PrePersist
	public void prePersist(Object value) {
		if (value instanceof ChangeableData changeableData) {
			changeableData.getChangeData().setCreated(new Date());
			changeableData.getChangeData().setCreatedBy(this.getCurrentUser());
		}
		this.preUpdate(value);
	}

	private String getCurrentUser() {
		return Optional.ofNullable(securityContext.getCallerPrincipal())
				.map(s -> s.getName())
				.orElse("unbekannt");
	}

	@PreUpdate
	public void preUpdate(Object value) {
		if (value instanceof ChangeableData changeableData) {
			changeableData.getChangeData().setUpdated(new Date());
			changeableData.getChangeData().setUpdatedBy(this.getCurrentUser());
		}
	}

}
