package stateless.zinsdienst;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.ejb.Stateless;
import jakarta.interceptor.Interceptors;

@Stateless
@Interceptors(value = {LifeCycleMonitor.class})
public class ZinssatzBean implements Zinssatz {

	public double ermittleZinssatz(int anlagebetrag, int jahre) {
		return 0.01 * jahre;
	}
	
	@PostConstruct
	private void beanErzeugt() {
		System.out.println("Es wurde eine Bean vom Typ " + this.getClass().getName() + " erzeugt.");
	}
	
	@PreDestroy
	private void beanEntfernt() {
		System.out.println("Es wird eine Bean vom Typ " + this.getClass().getName() + " entfernt.");
	}

}
