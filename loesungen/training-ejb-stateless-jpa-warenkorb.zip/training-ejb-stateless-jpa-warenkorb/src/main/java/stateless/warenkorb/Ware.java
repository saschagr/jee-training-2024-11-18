package stateless.warenkorb;

import java.io.Serializable;

public class Ware implements Serializable {

	private static final long serialVersionUID = 7423325659932458440L;

	int anzahl;

	int einzelpreis;

	String artikelnummer;

	public Ware(int anzahl, int einzelpreis, String artikelnummer) {
		super();
		this.anzahl = anzahl;
		this.einzelpreis = einzelpreis;
		this.artikelnummer = artikelnummer != null ? artikelnummer : "";
	}

	public int getGesamtpreis() {
		return anzahl * einzelpreis;
	}

	@Override
	public String toString() {
		return "Ware [anzahl=" + anzahl + ", einzelpreis=" + einzelpreis
				+ ", artikelnummer=" + artikelnummer + "]";
	}

	public int getAnzahl() {
		return anzahl;
	}

	public int getEinzelpreis() {
		return einzelpreis;
	}

	public String getArtikelnummer() {
		return artikelnummer;
	}
	
	
}
