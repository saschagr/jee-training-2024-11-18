package stateless.zinsrechner.ejb3;

import jakarta.annotation.PostConstruct;
import jakarta.ejb.Stateless;
import jakarta.interceptor.Interceptors;

@Stateless
@Interceptors(LifeCycleMonitor.class)
public class ZinsrechnerBean implements Zinsrechner {
	
	@PostConstruct
	public void init() {
		System.out.println("Hallo ich lebe " + this.getClass().getName());
	}

	public int berechneSparSumme(int anlagebetrag, int jahre, double zinssatz) {
		return (int) (anlagebetrag * Math.pow((100 + zinssatz) / 100, jahre));
	}
}
