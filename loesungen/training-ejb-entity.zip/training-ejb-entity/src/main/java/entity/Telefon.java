package entity;

import java.io.Serializable;

import jakarta.persistence.Embeddable;

@Embeddable
public class Telefon implements Serializable {
	
	private String nummer;
	
	public Telefon() {}
	
	public Telefon(String nummer) {
		this.nummer = nummer;
	}
	

	@Override
	public String toString() {
		return "Telefon [nummer=" + nummer + "]";
	}

	public String getNummer() {
		return nummer;
	}

	public void setNummer(String nummer) {
		this.nummer = nummer;
	}

}
