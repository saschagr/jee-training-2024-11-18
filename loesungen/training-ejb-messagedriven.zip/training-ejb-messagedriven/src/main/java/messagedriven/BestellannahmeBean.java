/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/
package messagedriven;

import java.util.Enumeration;

import jakarta.ejb.ActivationConfigProperty;
import jakarta.ejb.EJBException;
import jakarta.ejb.MessageDriven;
import jakarta.jms.JMSException;
import jakarta.jms.MapMessage;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;

@MessageDriven(name = "Bestellannahme", activationConfig = {
		@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "jakarta.jms.Queue"),
		@ActivationConfigProperty(propertyName = "destination", propertyValue = "jms/queue/PraxisbuchBestellung") })
public class BestellannahmeBean implements MessageListener {
	public void onMessage(Message nachricht) {
		try {
			MapMessage map = (MapMessage) nachricht;
			@SuppressWarnings("unchecked")
			Enumeration<String> artikelnummern = map.getMapNames();
			while (artikelnummern.hasMoreElements()) {
				String artikelnummer = artikelnummern.nextElement();
				System.out.println(artikelnummer + " : " + map.getInt(artikelnummer) + " Stück");
			}
		} catch (JMSException e) {
			throw new EJBException(e);
		}
	}
}
