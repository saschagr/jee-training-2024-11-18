package stateless.kaffeepause;

import java.util.concurrent.Future;

import jakarta.ejb.Remote;

@Remote
public interface KaffeeMaschine {


	public Future<Kaffee> kocheKaffee();

}