package entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderColumn;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Null;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@NamedQuery(
		name = Kunde.QUERY_FINDE_KUNDE_BY_NACHNAME,
		query = "select k from Customer k where k.nachname=:nachname")
@NamedQuery(
		name = Kunde.QUERY_FINDE_KUNDE_BY_TELEFONNUMMER_AND_VORNAME,
		query = "select k from Customer k where k.vorname=:vorname and :telefonnummer MEMBER OF k.telefons")
@Entity(name = "Customer")
public class Kunde implements Serializable{
	
	public static final String QUERY_FINDE_KUNDE_BY_NACHNAME = "findeKundeByNachname";
	public static final String QUERY_FINDE_KUNDE_BY_TELEFONNUMMER_AND_VORNAME = "findeKundeByTelefonnummerAndVorname";
	
	public static final String PARAM_NACHNAME = "nachname";
	public static final String PARAM_VORNAME = "vorname";
	public static final String PARAM_TELEFONNUMMER = "telefonnummer";
	
	@Id
	@GeneratedValue
	private int id;
	
	@NotBlank
	@Size(min = 3, max = 50)
	@Pattern(regexp = "[A-Z][a-züäö]{2,49}")
	private String vorname;
	@Column(name="lastname")
	@NotNull
	private String nachname;
	
	@Temporal(TemporalType.DATE)
	private Date geburtDatum;
	
	//Enum Anrede mit Frau, Herr, ...
	@Enumerated(EnumType.STRING)
	private Anrede anrede;
	
	//oder List<Telefon>
	@ElementCollection(fetch = FetchType.EAGER)
	@OrderColumn
	private List<Telefon> telefons = new ArrayList<>();
	
	@Embedded
	@AttributeOverride(
			name = "nummer", 
			column = @Column(name= "telefon_nummer"))
	private Telefon telefon;

	@Embedded
	@AttributeOverride(
			name = "nummer", 
			column = @Column(name= "fax_nummer"))
	private Telefon fax;

	@Version
	private int version;
	
	// undirektional One to Many
	// Ware hat artikelnummer, preis, anzahl
	@OneToMany(
			cascade = CascadeType.ALL, 
			fetch = FetchType.EAGER
			)
	@JoinColumn(name = "kunden_id")
	private List<Ware> warekorb = new ArrayList<>();

	
	public Kunde() {}
	
	public Kunde(String vorname, String nachname, Date geburtDatum, Anrede anrede, List<Telefon> telefons) {
		this.vorname = vorname;
		this.nachname = nachname;
		this.geburtDatum = geburtDatum;
		this.anrede = anrede;
		this.telefons = telefons;
	}

	public Date getGeburtDatum() {
		return geburtDatum;
	}
	public void setGeburtDatum(Date geburtDatum) {
		this.geburtDatum = geburtDatum;
	}
	public List<Telefon> getTelefons() {
		return telefons;
	}
	public void setTelefons(List<Telefon> telefons) {
		this.telefons = telefons;
	}
	public Telefon getFax() {
		return fax;
	}

	public void setFax(Telefon fax) {
		this.fax = fax;
	}

	public int getVersion() {
		return version;
	}
	
	
	public String getVorname() {
		return vorname;
	}
	public void setVorname(String vorname) {
		this.vorname = vorname;
	}
	public String getNachname() {
		return nachname;
	}
	public void setNachname(String nachname) {
		this.nachname = nachname;
	}
	public int getId() {
		return id;
	}
	
	public List<Ware> getWarekorb() {
		return warekorb;
	}

	public void setWarekorb(List<Ware> warekorb) {
		this.warekorb = warekorb;
	}


	
	@Override
	public String toString() {
		return "Kunde [id=" + id + ", vorname=" + vorname + ", nachname=" + nachname + ", geburtDatum=" + geburtDatum
				+ ", anrede=" + anrede + ", telefons=" + telefons + ", telefon=" + telefon + ", version=" + version
				+ ", warekorb=" + warekorb + "]";
	}
}
