/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/
package hello;

import java.util.Map;

import javax.naming.InitialContext;

public class HelloWorldClient {

	public static void main(String[] args) throws Exception {
		InitialContext context = new InitialContext();

		HelloWorld hello = (HelloWorld) context.lookup("training-ejb-security/HelloWorldSecuredBean!hello.HelloWorld");

		try {
			System.out.println(hello.hello("World!"));
		} catch (Exception e) {
			System.out.println("hello - " + e.getMessage());
		}

		try {
			System.out.println(hello.helloGuestAdminWrong("World!"));
		} catch (Exception e) {
			System.out.println("helloGuestAdminWrong - " + e.getMessage());
		}

		try {
			System.out.println(hello.helloGuest("World!"));
		} catch (Exception e) {
			System.out.println("helloGuest - " + e.getMessage());
		}

		try {
			System.out.println(hello.helloAdmin("World!"));
		} catch (Exception e) {
			System.out.println("helloAdmin - " + e.getMessage());
		}

		try {
			System.out.println(hello.helloGuestAdmin("World!"));
		} catch (Exception e) {
			System.out.println("helloGuestAdmin - " + e.getMessage());
		}
	}
}
