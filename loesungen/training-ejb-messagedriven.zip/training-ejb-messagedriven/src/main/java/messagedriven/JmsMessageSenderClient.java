/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/
package messagedriven;

import jakarta.jms.Connection;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.Destination;
import jakarta.jms.MapMessage;
import jakarta.jms.MessageProducer;
import jakarta.jms.Session;
import javax.naming.InitialContext;

public class JmsMessageSenderClient {
	public static void main(String[] args) throws Exception {
		InitialContext initialContext = new InitialContext();
		ConnectionFactory factory = (ConnectionFactory) initialContext.lookup("jms/RemoteConnectionFactory");
		try (Connection connection = factory.createConnection("app", "jboss");
				Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE)) {
			
			connection.start();

			MapMessage nachricht = session.createMapMessage();
			nachricht.setStringProperty("Bestellungstyp", "Internet");
			nachricht.setInt("0-24235-X", 5);
			nachricht.setInt("0-28543-X", 1);
			nachricht.setInt("0-23425-2", 3);

			Destination ziel = (Destination) initialContext.lookup("jms/queue/PraxisbuchBestellung");

			try (MessageProducer sender = session.createProducer(ziel)) {
				System.out.println("Sende Nachricht...");
				sender.send(nachricht);
				System.out.println("Nachricht gesendet");
			}
			connection.stop();
		}

	}
}
