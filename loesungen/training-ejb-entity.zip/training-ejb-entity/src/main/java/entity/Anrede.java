package entity;

public enum Anrede {
	
	FRAU,
	HERR,
	UNBEKANNT

}
