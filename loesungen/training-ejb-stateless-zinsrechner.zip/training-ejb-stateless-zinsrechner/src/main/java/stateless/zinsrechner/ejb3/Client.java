/**********************************************************
* Begleitmaterial zum Buch "Enterprise JavaBeans 3.1"
* Das EJB-Praxisbuch fuer Ein- und Umsteiger
* Von Werner Eberling und Jan Lessner
* Hanser Fachbuchverlag Muenchen, 2011
* http://www.hanser.de/buch.asp?isbn=3-446-42259-5
* Feedback an ejb3buch@werner-eberling.de
**********************************************************/
package stateless.zinsrechner.ejb3;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.naming.InitialContext;
import javax.naming.NamingException;

public class Client {

	public static void main(String[] args) throws Exception {
		InitialContext ctx = new InitialContext();
		
		Runnable runnable = () -> {
			try {

				Zinsrechner rechner = (Zinsrechner) ctx.lookup(
						"training-ejb-stateless-zinsrechner/ZinsrechnerBean!stateless.zinsrechner.ejb3.Zinsrechner");

				System.out.println(rechner.berechneSparSumme(24000, 5, 0.03));
			} catch (NamingException e) {
				throw new RuntimeException(e);
			}

		};

		ExecutorService executorService = Executors.newFixedThreadPool(20);

		for (int i = 0; i < 100; i++) {
			executorService.execute(runnable);
		}

		executorService.awaitTermination(5, TimeUnit.SECONDS);
		executorService.shutdown();
	}

}
