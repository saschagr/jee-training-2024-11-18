package stateless.warenkorb.entity;

import java.io.Serializable;

import jakarta.persistence.Embeddable;

@Embeddable
public class WarenkorbEintrag implements Serializable {

	private static final long serialVersionUID = 1433769080882235158L;

	private int anzahl;

	private int einzelpreis;

	private String artikelnummer;

	public WarenkorbEintrag() {
		super();
	}

	public WarenkorbEintrag(int anzahl, int einzelpreis, String artikelnummer) {
		super();
		this.anzahl = anzahl;
		this.einzelpreis = einzelpreis;
		this.artikelnummer = artikelnummer;
	}


	public int getAnzahl() {
		return anzahl;
	}

	public void setAnzahl(int anzahl) {
		this.anzahl = anzahl;
	}

	public int getEinzelpreis() {
		return einzelpreis;
	}

	public void setEinzelpreis(int einzelpreis) {
		this.einzelpreis = einzelpreis;
	}

	public String getArtikelnummer() {
		return artikelnummer;
	}

	public void setArtikelnummer(String artikelnummer) {
		this.artikelnummer = artikelnummer;
	}

}
