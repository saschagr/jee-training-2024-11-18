package stateless.zinsdienst;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.ejb.Stateless;
import jakarta.interceptor.Interceptors;

@Stateless
@Interceptors(value = {LifeCycleMonitor.class})
public class ZinrechnerMitZinssatzBean implements ZinsrechnerMitZinssatz {
	
	@jakarta.ejb.EJB
	private Zinssatz zinssatz;
	

	public int berechneSparSumme(int anlagebetrag, int jahre) {
		double zins = zinssatz.ermittleZinssatz(anlagebetrag, jahre);
		
		return (int) (anlagebetrag * Math.pow((1+zins), jahre));
	}
	
	@PostConstruct
	private void beanErzeugt() {
		System.out.println("Es wurde eine Bean vom Typ " + this.getClass().getName() + " erzeugt.");
	}
	
	@PreDestroy
	private void beanEntfernt() {
		System.out.println("Es wird eine Bean vom Typ " + this.getClass().getName() + " entfernt.");
	}
}